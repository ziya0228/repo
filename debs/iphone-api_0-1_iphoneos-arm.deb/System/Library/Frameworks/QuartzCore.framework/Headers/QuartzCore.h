/* QuartzCore.h

   Copyright (c) 2004 Apple Computer, Inc.
   All rights reserved. */

#import <QuartzCore/CoreAnimation.h>
