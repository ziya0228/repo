#ifndef __NET_DISCONNECT_H
#define __NET_DISCONNECT_H

void net_disconnect_init(void);
void net_disconnect_deinit(void);

#endif
