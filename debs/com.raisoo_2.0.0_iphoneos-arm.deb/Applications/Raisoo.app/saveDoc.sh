#!/bin/sh
cp /tmp/$1 /var/mobile/Documents/$1